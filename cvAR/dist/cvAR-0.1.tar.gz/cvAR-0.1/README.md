# cvAR
This module is use to make AR projects

## Installation
```pip install cvAR```

## License

© 2022 ELEVEN

This repository is licensed under the MIT license. See LICENSE for details.
